package Bus;

public enum AccountType {
	Checking,Saving,Credit,Currency

}
