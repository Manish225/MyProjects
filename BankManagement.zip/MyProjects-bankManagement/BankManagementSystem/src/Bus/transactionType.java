package Bus;

public enum transactionType {
deposit,withdraw,checkBalance
}
