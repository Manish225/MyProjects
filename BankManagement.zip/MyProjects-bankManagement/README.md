# MyProjects
Bank Management Application: It is application using java managing 2 different types of accounts for customers with balance
