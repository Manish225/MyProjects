﻿namespace MiniAccess.GUI
{
    partial class CreatingtheDatabase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddTable = new System.Windows.Forms.Button();
            this.txtTableName = new System.Windows.Forms.TextBox();
            this.btnRelation = new System.Windows.Forms.Button();
            this.buttonIndex = new System.Windows.Forms.Button();
            this.cmbTables = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnAddTable
            // 
            this.btnAddTable.Location = new System.Drawing.Point(30, 27);
            this.btnAddTable.Name = "btnAddTable";
            this.btnAddTable.Size = new System.Drawing.Size(75, 23);
            this.btnAddTable.TabIndex = 0;
            this.btnAddTable.Text = "Add Table";
            this.btnAddTable.UseVisualStyleBackColor = true;
            this.btnAddTable.Click += new System.EventHandler(this.btnAddTable_Click);
            // 
            // txtTableName
            // 
            this.txtTableName.Location = new System.Drawing.Point(175, 30);
            this.txtTableName.Name = "txtTableName";
            this.txtTableName.Size = new System.Drawing.Size(121, 20);
            this.txtTableName.TabIndex = 1;
            // 
            // btnRelation
            // 
            this.btnRelation.Location = new System.Drawing.Point(337, 30);
            this.btnRelation.Name = "btnRelation";
            this.btnRelation.Size = new System.Drawing.Size(98, 23);
            this.btnRelation.TabIndex = 2;
            this.btnRelation.Text = "Create Relation";
            this.btnRelation.UseVisualStyleBackColor = true;
            this.btnRelation.Click += new System.EventHandler(this.btnRelation_Click);
            // 
            // buttonIndex
            // 
            this.buttonIndex.Location = new System.Drawing.Point(30, 57);
            this.buttonIndex.Name = "buttonIndex";
            this.buttonIndex.Size = new System.Drawing.Size(118, 23);
            this.buttonIndex.TabIndex = 4;
            this.buttonIndex.Text = "Change Index";
            this.buttonIndex.UseVisualStyleBackColor = true;
            this.buttonIndex.Click += new System.EventHandler(this.buttonIndex_Click);
            // 
            // cmbTables
            // 
            this.cmbTables.FormattingEnabled = true;
            this.cmbTables.Location = new System.Drawing.Point(175, 58);
            this.cmbTables.Name = "cmbTables";
            this.cmbTables.Size = new System.Drawing.Size(121, 21);
            this.cmbTables.TabIndex = 5;
            this.cmbTables.Tag = "Tables Combo Box";
            // 
            // CreatingtheDatabase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 300);
            this.Controls.Add(this.cmbTables);
            this.Controls.Add(this.buttonIndex);
            this.Controls.Add(this.btnRelation);
            this.Controls.Add(this.txtTableName);
            this.Controls.Add(this.btnAddTable);
            this.Name = "CreatingtheDatabase";
            this.Text = "CreatingtheDatabase";
            this.Load += new System.EventHandler(this.CreatingtheDatabase_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddTable;
        private System.Windows.Forms.TextBox txtTableName;
        private System.Windows.Forms.Button btnRelation;
        private System.Windows.Forms.Button buttonIndex;
        private System.Windows.Forms.ComboBox cmbTables;
    }
}