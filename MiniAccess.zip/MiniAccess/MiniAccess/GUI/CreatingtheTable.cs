﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAO;
namespace MiniAccess.GUI
{
    public partial class CreatingtheTable : Form
    {
        string path,TableName;
        public CreatingtheTable()
        {
            InitializeComponent();
        }

        void AddingaField()
        {
            ComboBox cbo = new ComboBox();
            cbo.SetBounds(x + 180, y + 30, 90, 40);
            if (i == 1)
            {
                cbo.Items.Add(DataTypeEnum.dbInteger);
                cbo.AllowDrop = false;
                cbo.SelectedIndex = 0;
            }
            else {

                DataTypeEnum num = DataTypeEnum.dbBoolean;
                for (int j = 0; j < 23; j++)
                {
                    if (j != 12 && j != 13)
                        cbo.Items.Add(num);
                    num++;
                }
                cbo.SelectedItem = DataTypeEnum.dbText;
            }

            TextBox txt = new TextBox();
            txt.SetBounds(x + 50, y + 30, 90, 40);
            y = y + 40;
            if(i==1)
            { txt.Text = "ID"; }
            else
            txt.Text = "Field" + (i-1);
            this.Controls.Add(txt);
            this.Controls.Add(cbo);

            txt.Name = "txt" + i;
            cbo.Name = "cbo" + i;
            i++;
           
        }
        public CreatingtheTable(string path,string TableName)
        {
            InitializeComponent();
            this.path = path;
            this.TableName = TableName;
        }

        TableDef myTB;
        Field myFL;
        int i =1;
        int x = 50, y = 30;

        private void CreatingtheTable_Load(object sender, EventArgs e)
        {

            AddingaField();
        }

        private void btnIndex_Click(object sender, EventArgs e)
        {
            
            Index myInd = myTB.CreateIndex("PrimaryKey");
            myFL = myInd.CreateField(this.Controls["txt1"].Text);
            ((IndexFields)(myInd.Fields)).Append(myFL);
            myInd.Primary = true;
            myTB.Indexes.Append(myInd);

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            bool ok=true;
            foreach(Control txt in this.Controls)
            {
                if(txt is TextBox)
                {
                    if(txt.Text.Trim()=="")
                    {
                        MessageBox.Show("You need to fill every field", "Warning");
                        ok = false;
                    }
                    for(int k=1;k<i;k++)
                    {
                        if(txt.Name!=this.Controls["txt"+k].Name)
                        {
                            if(txt.Text== this.Controls["txt" + k].Text)
                            {
                                MessageBox.Show("Every field should have different name !", "Warning");
                                ok = false;
                                break;
                            }
                        }
                    }
                    if(ok==false)
                    {
                        break;
                    }
               
                }

            }
            
            
            if (ok)
            {
                DBEngine dbe = new DBEngine();
                Database myDB = dbe.OpenDatabase(path);
                
                myTB = myDB.CreateTableDef(TableName);
                for (int j = 1; j < i; j++)
                {


                    myFL = myTB.CreateField((this.Controls["txt" + j]).Text, ((ComboBox)(this.Controls["cbo" + j])).SelectedItem);
                    myTB.Fields.Append(myFL);
                }


                Index myInd = myTB.CreateIndex("PrimaryKey");
                myFL = myInd.CreateField(this.Controls["txt1"].Text);
                ((IndexFields)(myInd.Fields)).Append(myFL);
                myInd.Primary = true;
                myTB.Indexes.Append(myInd);


                myDB.TableDefs.Append(myTB);
                myDB.Close();
                MessageBox.Show("Your Table has been Saved","Confirmation");

                this.Close();
            }

        }
        
        

        private void btnAddingfield_Click(object sender, EventArgs e)
        {
            AddingaField();
            
        }
    }
}
