﻿namespace MiniAccess.GUI
{
    partial class CreatingtheRelation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbTable = new System.Windows.Forms.ComboBox();
            this.cmbForeignTable = new System.Windows.Forms.ComboBox();
            this.lblTable = new System.Windows.Forms.Label();
            this.lblForeignTable = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRelationName = new System.Windows.Forms.TextBox();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmbTable
            // 
            this.cmbTable.FormattingEnabled = true;
            this.cmbTable.Location = new System.Drawing.Point(113, 89);
            this.cmbTable.Name = "cmbTable";
            this.cmbTable.Size = new System.Drawing.Size(121, 21);
            this.cmbTable.TabIndex = 0;
            this.cmbTable.Tag = "Table";
            this.cmbTable.SelectedIndexChanged += new System.EventHandler(this.cmbTable_SelectedIndexChanged);
            // 
            // cmbForeignTable
            // 
            this.cmbForeignTable.FormattingEnabled = true;
            this.cmbForeignTable.Location = new System.Drawing.Point(113, 130);
            this.cmbForeignTable.Name = "cmbForeignTable";
            this.cmbForeignTable.Size = new System.Drawing.Size(121, 21);
            this.cmbForeignTable.TabIndex = 1;
            this.cmbForeignTable.Tag = "Foreign Table";
            this.cmbForeignTable.SelectedIndexChanged += new System.EventHandler(this.cmbForeignTable_SelectedIndexChanged);
            // 
            // lblTable
            // 
            this.lblTable.AutoSize = true;
            this.lblTable.Location = new System.Drawing.Point(12, 92);
            this.lblTable.Name = "lblTable";
            this.lblTable.Size = new System.Drawing.Size(40, 13);
            this.lblTable.TabIndex = 2;
            this.lblTable.Text = "Table :";
            // 
            // lblForeignTable
            // 
            this.lblForeignTable.AutoSize = true;
            this.lblForeignTable.Location = new System.Drawing.Point(12, 133);
            this.lblForeignTable.Name = "lblForeignTable";
            this.lblForeignTable.Size = new System.Drawing.Size(78, 13);
            this.lblForeignTable.TabIndex = 3;
            this.lblForeignTable.Text = "Foreign Table :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Relation Name :";
            // 
            // txtRelationName
            // 
            this.txtRelationName.Location = new System.Drawing.Point(113, 53);
            this.txtRelationName.Name = "txtRelationName";
            this.txtRelationName.Size = new System.Drawing.Size(121, 20);
            this.txtRelationName.TabIndex = 5;
            this.txtRelationName.Tag = "Relation Name";
            this.txtRelationName.TextChanged += new System.EventHandler(this.txtRelationName_TextChanged);
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(126, 196);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(75, 23);
            this.buttonSave.TabIndex = 6;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(207, 196);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 7;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // CreatingtheRelation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 231);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.txtRelationName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblForeignTable);
            this.Controls.Add(this.lblTable);
            this.Controls.Add(this.cmbForeignTable);
            this.Controls.Add(this.cmbTable);
            this.Name = "CreatingtheRelation";
            this.Text = "CreatingtheRelation";
            this.Load += new System.EventHandler(this.CreatingtheRelation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbTable;
        private System.Windows.Forms.ComboBox cmbForeignTable;
        private System.Windows.Forms.Label lblTable;
        private System.Windows.Forms.Label lblForeignTable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRelationName;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonCancel;
    }
}