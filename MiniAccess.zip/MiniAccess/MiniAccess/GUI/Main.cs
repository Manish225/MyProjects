﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAO;
using System.IO;

namespace MiniAccess.GUI
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        SaveFileDialog save = new SaveFileDialog();
        string path;
        private void databaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            
            //string path= save.;
            save.DefaultExt= ".accdb";

            //Database myDB = dbe.CreateDatabase(path,DAO.LanguageConstants.dbLangGeneral);
            save.FileOk += save_click;
           
            save.ShowDialog();
            if (path != null)
            {
                CreatingtheDatabase frm = new CreatingtheDatabase(path);
                frm.ShowDialog();
            }
        }
        private void save_click(object sender, EventArgs e)
        {
            path = save.FileName;
            DBEngine dbe = new DBEngine();
            if(File.Exists(path))
            {
                File.Delete(path);
            }
            Database myDB = dbe.CreateDatabase(path, DAO.LanguageConstants.dbLangGeneral);
          
            
         
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure that you want quit the program?", "Closing Application", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
