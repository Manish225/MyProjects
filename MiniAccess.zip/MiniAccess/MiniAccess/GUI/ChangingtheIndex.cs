﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAO;

namespace MiniAccess.GUI
{
    public partial class ChangingtheIndex : Form
    {
        string path;
        string TableName;
        Database myDB;
        TableDef myTB;
        Field myFL;
        public ChangingtheIndex()
        {
            InitializeComponent();
        }
        public ChangingtheIndex(string path,string TableName)
        {
            InitializeComponent();
            this.path = path;
            this.TableName = TableName;
        }

        private void ChangingtheIndex_Load(object sender, EventArgs e)
        {

            DBEngine dbe = new DBEngine();
            myDB=dbe.OpenDatabase(path);
            foreach(Field myFL in myDB.TableDefs[TableName].Fields)
            {
                cmbFields.Items.Add(myFL.Name);
            }
        }

        private void btnTndex_Click(object sender, EventArgs e)
        {
            if (cmbFields.Text.Trim() != "")
            {
                myTB = myDB.TableDefs[TableName];
                myTB.Indexes.Delete("PrimaryKey");
                Index myInd = myTB.CreateIndex("PrimaryKey");
                myFL = myInd.CreateField(cmbFields.SelectedItem);
                ((IndexFields)(myInd.Fields)).Append(myFL);
                myInd.Primary = true;
                myTB.Indexes.Append(myInd);
                MessageBox.Show("Index is" + cmbFields.Text.Trim());
                this.Close();
            }
            else
            {
                MessageBox.Show("Please select a Field");
              
            }
        }
    }
}
