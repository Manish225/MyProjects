﻿namespace MiniAccess.GUI
{
    partial class CreatingtheTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddingfield = new System.Windows.Forms.Button();
            this.buttonSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAddingfield
            // 
            this.btnAddingfield.Location = new System.Drawing.Point(503, 291);
            this.btnAddingfield.Name = "btnAddingfield";
            this.btnAddingfield.Size = new System.Drawing.Size(75, 23);
            this.btnAddingfield.TabIndex = 0;
            this.btnAddingfield.Text = "Add a Field";
            this.btnAddingfield.UseVisualStyleBackColor = true;
            this.btnAddingfield.Click += new System.EventHandler(this.btnAddingfield_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(584, 291);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(75, 23);
            this.buttonSave.TabIndex = 1;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // CreatingtheTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(711, 335);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.btnAddingfield);
            this.Name = "CreatingtheTable";
            this.Text = "CreatingtheTable";
            this.Load += new System.EventHandler(this.CreatingtheTable_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAddingfield;
        private System.Windows.Forms.Button buttonSave;
    }
}