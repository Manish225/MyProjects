﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAO;

namespace MiniAccess.GUI
{
    public partial class CreatingtheDatabase : Form
    {
        string path;
        public CreatingtheDatabase()
        {
            InitializeComponent();
        }
        bool Empty(ComboBox cmb)
        {
            if (cmb.Text.Trim() == "")
            {
                MessageBox.Show("No Data in Combobox Tables");
                cmb.Focus();
                return true;
            }
            return false;
        }
        public CreatingtheDatabase(string path)
        {
            this.path = path;
            InitializeComponent();
        }

        Database myDB;
        

        private void btnAddTable_Click(object sender, EventArgs e)
        {

            DBEngine dbe = new DBEngine();
            myDB = dbe.OpenDatabase(path);
            bool exists = false;
           

            if (txtTableName.Text.Trim() != "")
            {
                foreach (TableDef myTB in myDB.TableDefs)
                {
                    if (myTB.Name == txtTableName.Text)
                    {
                        exists = true;
                        MessageBox.Show("Table with this Name already exists");
                    }

                }
                if (!exists)
                {
                    CreatingtheTable Tb = new CreatingtheTable(path, txtTableName.Text);
                    Tb.ShowDialog();


                    cmbTables.Items.Clear();
                    
                    myDB.Close();
                    myDB = dbe.OpenDatabase(path);
                    foreach (TableDef myTB in myDB.TableDefs)
                    {
                        if (myTB.Attributes == 0)
                        {
                            cmbTables.Items.Add(myTB.Name);
                        }
                    }

                }
            }
            else
                MessageBox.Show("Please Enter the Table Name!","Warning");

            myDB.Close();

        }

        private void CreatingtheDatabase_Load(object sender, EventArgs e)
        {
            
            DBEngine dbe = new DBEngine();
            myDB = dbe.OpenDatabase(path);

            cmbTables.Items.Clear();
            
            foreach (TableDef myTB in myDB.TableDefs)
            {
                if (myTB.Attributes == 0)
                {
                    cmbTables.Items.Add(myTB.Name);
                }
            }
            
        }

        private void btnRelation_Click(object sender, EventArgs e)
        {
            CreatingtheRelation rel = new CreatingtheRelation(path);
            rel.ShowDialog();

        }

        private void buttonIndex_Click(object sender, EventArgs e)
        {
            if (!Empty(cmbTables))
            {
                ChangingtheIndex frm = new ChangingtheIndex(path, cmbTables.SelectedItem.ToString());
                frm.ShowDialog();
            }
        }
    }
}
