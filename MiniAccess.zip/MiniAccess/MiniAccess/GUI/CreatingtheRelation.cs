﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAO;

namespace MiniAccess.GUI
{
    public partial class CreatingtheRelation : Form
    {
        string path;
        Database myDB;
        TableDef myTB;
        Field myFL;
        int i=1;
        bool Empty(TextBox txt)
        {
            if (txt.Text.Trim() == "")
            {
                MessageBox.Show("You need to enter data in " + txt.Tag);
                txt.Focus();
                return true;
            }
            return false;
        }
        bool Empty(ComboBox cmb)
        {
            if (cmb.Text.Trim() == "")
            {
                MessageBox.Show("You need to enter data in " + cmb.Tag);
                cmb.Focus();
                return true;
            }
            return false;
        }
        public CreatingtheRelation()
        {
            InitializeComponent();
        }

        public CreatingtheRelation(string path)
        {
            InitializeComponent();
            this.path = path;
        }
        private void CreatingtheRelation_Load(object sender, EventArgs e)
        {
            DBEngine dbe = new DBEngine();
            myDB = dbe.OpenDatabase(path);
             foreach(TableDef myTb in myDB.TableDefs)
            {
                if (myTb.Attributes == 0)
                {
                    cmbTable.Items.Add(myTb.Name);
                    
                }
            }
           

        }

        private void cmbTable_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (i != 1)
            {
                this.Controls.Remove(this.Controls["txt"]);
                
                
            }
           
               

            TextBox txt = new TextBox();
            txt.SetBounds(240, 89, 121, 21);
            this.Controls.Add(txt);
            myTB = myDB.TableDefs[cmbTable.SelectedItem];
            foreach (Index myIN in myTB.Indexes)
            {
                if (myIN.Primary == true)
                    myFL = (Field)((IndexFields)(myIN.Fields))[0];
            }
            txt.Text = myFL.Name;
            txt.ReadOnly = true;
            txt.Name = "txt";
            i++;
            cmbForeignTable.Items.Clear();
            foreach (TableDef myTb in myDB.TableDefs)
            {
                if (myTb.Attributes == 0 && myTb.Name!=cmbTable.SelectedItem.ToString())
                {
                    cmbForeignTable.Items.Add(myTb.Name);

                }
            }
            cmbForeignTable.Text = "";


        }

        private void cmbForeignTable_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (i != 1)
            {
                this.Controls.Remove(this.Controls["cmb"]);
            }
            ComboBox cmb = new ComboBox();
            cmb.SetBounds(240, 130, 121, 21);
            this.Controls.Add(cmb);
           
            foreach(Field myFl in myDB.TableDefs[cmbForeignTable.SelectedItem].Fields)
            {
                
                cmb.Items.Add(myFl.Name);
            }
            cmb.Name = "cmb";
            cmb.SelectedIndex = 0;

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (!Empty(txtRelationName) && !Empty(cmbTable) && !Empty(cmbTable) )
            {



                if (myDB.TableDefs[cmbTable.SelectedItem].Fields[this.Controls["txt"].Text].Type == myDB.TableDefs[cmbForeignTable.SelectedItem].Fields[((ComboBox)this.Controls["cmb"]).SelectedItem].Type)
                {
                    Relation myRel = myDB.CreateRelation(txtRelationName.Text, cmbTable.SelectedItem, cmbForeignTable.SelectedItem);
                    myFL = myRel.CreateField(this.Controls["txt"].Text);
                    myFL.ForeignName = this.Controls["cmb"].Text;
                    myRel.Fields.Append(myFL);

                    myDB.Relations.Append(myRel);
                    myDB.Close();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("You cannot create relation between fields of different data type");
                }
            }
           
            
        }

        private void txtRelationName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
